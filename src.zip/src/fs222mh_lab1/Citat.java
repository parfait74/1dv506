package fs222mh_lab1;

public class Citat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String text = "I wish I was a punk rocker with flowers in my hair.";
		System.out.println("\"" +text + "\"" );

	}

}
