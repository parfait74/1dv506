package fs222mh_lab1;

public class Sekunder {

	public static void main(String[] args) {
		int hours = 2;
		int minutes = 24;
		int sekunds = 14;
		int totalSekunds = (hours * 60 * 60) + (minutes * 60) + sekunds;  
		System.out.println(totalSekunds);

	}

}
