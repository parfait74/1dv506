package fs222mh_lab1;

public class Print {
	public static void main (String[] args) {
		System.out.println("Kunskap är makt!");
		System.out.println("Kunskap\när\nmakt!");
		System.out.println("|================|\n|Kunskap är makt!|\n|================|");
		
	}
		
	}


